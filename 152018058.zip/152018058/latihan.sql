-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.11-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for latihan
CREATE DATABASE IF NOT EXISTS `latihan` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `latihan`;

-- Dumping structure for table latihan.daftarbarang058
CREATE TABLE IF NOT EXISTS `daftarbarang058` (
  `kode_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(20) DEFAULT NULL,
  `harga_barang` int(11) DEFAULT NULL,
  PRIMARY KEY (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table latihan.daftarbarang058: ~4 rows (approximately)
DELETE FROM `daftarbarang058`;
/*!40000 ALTER TABLE `daftarbarang058` DISABLE KEYS */;
INSERT INTO `daftarbarang058` (`kode_barang`, `nama_barang`, `harga_barang`) VALUES
	('B-01', 'Baju Tangan Pendek', 120000),
	('B-02', 'Baju Tangan Panjang', 150000),
	('J-02', 'Jas Hujan', 15000),
	('K-01', 'Kimono', 60000);
/*!40000 ALTER TABLE `daftarbarang058` ENABLE KEYS */;

-- Dumping structure for table latihan.pelanggan058
CREATE TABLE IF NOT EXISTS `pelanggan058` (
  `id_pelanggan` varchar(4) NOT NULL,
  `nama` varchar(20) DEFAULT NULL,
  `kota` varchar(20) DEFAULT NULL,
  `nohp` varchar(13) DEFAULT NULL,
  PRIMARY KEY (`id_pelanggan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table latihan.pelanggan058: ~3 rows (approximately)
DELETE FROM `pelanggan058`;
/*!40000 ALTER TABLE `pelanggan058` DISABLE KEYS */;
INSERT INTO `pelanggan058` (`id_pelanggan`, `nama`, `kota`, `nohp`) VALUES
	('D-02', 'Dewi Susanti', 'Jakarta', '08113456'),
	('E-02', 'Ernawati', 'Bogor', '08156667788'),
	('R-01', 'Rahmawati', 'Bandung', '022-234567');
/*!40000 ALTER TABLE `pelanggan058` ENABLE KEYS */;

-- Dumping structure for table latihan.sales058
CREATE TABLE IF NOT EXISTS `sales058` (
  `id_sales` varchar(4) NOT NULL,
  `nama` varchar(20) DEFAULT NULL,
  `P/W` enum('P','W') DEFAULT NULL,
  `Gender` varchar(7) DEFAULT NULL,
  PRIMARY KEY (`id_sales`),
  KEY `nama060` (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table latihan.sales058: ~3 rows (approximately)
DELETE FROM `sales058`;
/*!40000 ALTER TABLE `sales058` DISABLE KEYS */;
INSERT INTO `sales058` (`id_sales`, `nama`, `P/W`, `Gender`) VALUES
	('B-01', 'budiman', 'P', 'Pria'),
	('C-02', 'cyntia', 'W', 'Wanita'),
	('D-03', 'dani', 'P', 'pria');
/*!40000 ALTER TABLE `sales058` ENABLE KEYS */;

-- Dumping structure for table latihan.transaksi058
CREATE TABLE IF NOT EXISTS `transaksi058` (
  `id_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date DEFAULT NULL,
  `id_sales` varchar(4) NOT NULL,
  `Nama_sales` varchar(4) NOT NULL,
  `id_pelanggan` varchar(4) NOT NULL,
  `Nama_pelanggan` varchar(4) NOT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `FK_transaksi133_pelanggan133` (`id_pelanggan`),
  KEY `FK_transaksi133_sales133` (`id_sales`),
  CONSTRAINT `FK_transaksi_pelanggan` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan058` (`id_pelanggan`),
  CONSTRAINT `FK_transaksi_sales` FOREIGN KEY (`id_sales`) REFERENCES `sales058` (`id_sales`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table latihan.transaksi058: ~2 rows (approximately)
DELETE FROM `transaksi058`;
/*!40000 ALTER TABLE `transaksi058` DISABLE KEYS */;
INSERT INTO `transaksi058` (`id_transaksi`, `tanggal`, `id_sales`, `Nama_sales`, `id_pelanggan`, `Nama_pelanggan`) VALUES
	(1, '2011-02-03', 'B-01', 'Budi', 'D-02', ' Sus'),
	(2, '2011-04-05', 'C-02', 'Cynt', 'R-01', 'Rahm');
/*!40000 ALTER TABLE `transaksi058` ENABLE KEYS */;

-- Dumping structure for table latihan.transaksiitem058
CREATE TABLE IF NOT EXISTS `transaksiitem058` (
  `id_transaksi` int(11) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `Nama_barang` varchar(20) DEFAULT NULL,
  `quantity` int(3) DEFAULT NULL,
  KEY `id_transaksi060` (`id_transaksi`),
  KEY `FK_transaksiitem060_daftarbarang060` (`kode_barang`),
  CONSTRAINT `FK_transaksiitem_daftarbarang` FOREIGN KEY (`kode_barang`) REFERENCES `daftarbarang058` (`kode_barang`),
  CONSTRAINT `FK_transaksiitem_transaksi` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi058` (`id_transaksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table latihan.transaksiitem058: ~2 rows (approximately)
DELETE FROM `transaksiitem058`;
/*!40000 ALTER TABLE `transaksiitem058` DISABLE KEYS */;
INSERT INTO `transaksiitem058` (`id_transaksi`, `kode_barang`, `Nama_barang`, `quantity`) VALUES
	(1, 'B-02', 'Baju Tangan Panjang', 12),
	(1, 'J-02', 'Jas Hujan', 13);
/*!40000 ALTER TABLE `transaksiitem058` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
